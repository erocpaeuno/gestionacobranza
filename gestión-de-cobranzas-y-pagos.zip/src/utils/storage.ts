import {
  Cliente,
  Prestamo,
  Cuota,
  Pago,
  UsuarioConfig,
  ReciboGenerado,
} from '../types';
import {
  INITIAL_CLIENTES,
  INITIAL_PRESTAMOS,
  INITIAL_CUOTAS,
  INITIAL_PAGOS,
  INITIAL_CONFIG,
} from '../data/initialData';

const STORAGE_KEYS = {
  CLIENTES: 'gp_clientes_v1',
  PRESTAMOS: 'gp_prestamos_v1',
  CUOTAS: 'gp_cuotas_v1',
  PAGOS: 'gp_pagos_v1',
  CONFIG: 'gp_config_v1',
  RECIBOS: 'gp_recibos_historial_v1',
};

export function getStoredData() {
  const get = <T>(key: string, fallback: T): T => {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : fallback;
    } catch {
      return fallback;
    }
  };

  return {
    clientes: get<Cliente[]>(STORAGE_KEYS.CLIENTES, INITIAL_CLIENTES),
    prestamos: get<Prestamo[]>(STORAGE_KEYS.PRESTAMOS, INITIAL_PRESTAMOS),
    cuotas: get<Cuota[]>(STORAGE_KEYS.CUOTAS, INITIAL_CUOTAS),
    pagos: get<Pago[]>(STORAGE_KEYS.PAGOS, INITIAL_PAGOS),
    config: get<UsuarioConfig>(STORAGE_KEYS.CONFIG, INITIAL_CONFIG),
    recibos: get<ReciboGenerado[]>(STORAGE_KEYS.RECIBOS, []),
  };
}

export function saveStoredData(data: {
  clientes?: Cliente[];
  prestamos?: Prestamo[];
  cuotas?: Cuota[];
  pagos?: Pago[];
  config?: UsuarioConfig;
  recibos?: ReciboGenerado[];
}) {
  if (data.clientes) localStorage.setItem(STORAGE_KEYS.CLIENTES, JSON.stringify(data.clientes));
  if (data.prestamos) localStorage.setItem(STORAGE_KEYS.PRESTAMOS, JSON.stringify(data.prestamos));
  if (data.cuotas) localStorage.setItem(STORAGE_KEYS.CUOTAS, JSON.stringify(data.cuotas));
  if (data.pagos) localStorage.setItem(STORAGE_KEYS.PAGOS, JSON.stringify(data.pagos));
  if (data.config) localStorage.setItem(STORAGE_KEYS.CONFIG, JSON.stringify(data.config));
  if (data.recibos) localStorage.setItem(STORAGE_KEYS.RECIBOS, JSON.stringify(data.recibos));
}

export function resetDatabase() {
  localStorage.setItem(STORAGE_KEYS.CLIENTES, JSON.stringify(INITIAL_CLIENTES));
  localStorage.setItem(STORAGE_KEYS.PRESTAMOS, JSON.stringify(INITIAL_PRESTAMOS));
  localStorage.setItem(STORAGE_KEYS.CUOTAS, JSON.stringify(INITIAL_CUOTAS));
  localStorage.setItem(STORAGE_KEYS.PAGOS, JSON.stringify(INITIAL_PAGOS));
  localStorage.setItem(STORAGE_KEYS.CONFIG, JSON.stringify(INITIAL_CONFIG));
  localStorage.removeItem(STORAGE_KEYS.RECIBOS);
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('es-PE', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
  }).format(amount);
}

export function formatDate(dateString: string): string {
  if (!dateString) return '-';
  const parts = dateString.split('T')[0].split('-');
  if (parts.length === 3) {
    return `${parts[2]}/${parts[1]}/${parts[0]}`;
  }
  return dateString;
}

export function getTodayDateString(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getNowDateTimeString(): string {
  const now = new Date();
  return `${formatDate(now.toISOString())} ${now.toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  })}`;
}
