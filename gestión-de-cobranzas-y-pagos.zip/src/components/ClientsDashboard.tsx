import React, { useState, useMemo } from 'react';
import {
  Search,
  User,
  Phone,
  MessageCircle,
  AlertTriangle,
  CheckCircle2,
  ChevronRight,
  CreditCard,
  Filter,
  DollarSign,
  TrendingUp,
} from 'lucide-react';
import { Cliente, Prestamo, Cuota } from '../types';
import { formatCurrency } from '../utils/storage';
import { cleanPhoneNumber } from '../utils/whatsapp';

interface ClientsDashboardProps {
  clientes: Cliente[];
  prestamos: Prestamo[];
  cuotas: Cuota[];
  onSelectCliente: (cliente: Cliente) => void;
  onQuickPay: (cliente: Cliente, prestamo: Prestamo) => void;
}

export const ClientsDashboard: React.FC<ClientsDashboardProps> = ({
  clientes,
  prestamos,
  cuotas,
  onSelectCliente,
  onQuickPay,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterMode, setFilterMode] = useState<'ALL' | 'OVERDUE' | 'ACTIVE'>('ALL');

  // Map of client stats
  const clientStats = useMemo(() => {
    return clientes.map((cliente) => {
      const clientLoans = prestamos.filter((p) => p.cliente_dni === cliente.dni);
      const activeLoan = clientLoans.find((p) => p.estado === 'ACTIVO') || clientLoans[0];

      if (!activeLoan) {
        return {
          cliente,
          activeLoan: null,
          totalCuotas: 0,
          paidCuotasCount: 0,
          overdueCuotasCount: 0,
          pendingDebt: 0,
          hasOverdue: false,
        };
      }

      const loanCuotas = cuotas.filter((c) => c.prestamo_id === activeLoan.id);
      const paid = loanCuotas.filter((c) => c.estado === 'PAGADO');
      const overdue = loanCuotas.filter((c) => c.estado === 'VENCIDO');
      const pendingDebt = loanCuotas
        .filter((c) => c.estado !== 'PAGADO')
        .reduce((acc, c) => acc + (c.monto - c.monto_pagado) + c.mora, 0);

      return {
        cliente,
        activeLoan,
        totalCuotas: loanCuotas.length,
        paidCuotasCount: paid.length,
        overdueCuotasCount: overdue.length,
        pendingDebt,
        hasOverdue: overdue.length > 0,
      };
    });
  }, [clientes, prestamos, cuotas]);

  // Overall dashboard metrics
  const totalOverdueClients = clientStats.filter((c) => c.hasOverdue).length;
  const totalGlobalDebt = clientStats.reduce((acc, c) => acc + c.pendingDebt, 0);

  // Filter clients
  const filteredList = useMemo(() => {
    return clientStats.filter(({ cliente, hasOverdue, activeLoan }) => {
      const matchSearch =
        cliente.nombres.toLowerCase().includes(searchTerm.toLowerCase()) ||
        cliente.apellidos.toLowerCase().includes(searchTerm.toLowerCase()) ||
        cliente.dni.includes(searchTerm) ||
        cliente.codigo.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (activeLoan && activeLoan.id.toLowerCase().includes(searchTerm.toLowerCase()));

      if (!matchSearch) return false;

      if (filterMode === 'OVERDUE') return hasOverdue;
      if (filterMode === 'ACTIVE') return activeLoan?.estado === 'ACTIVO';
      return true;
    });
  }, [clientStats, searchTerm, filterMode]);

  return (
    <div className="space-y-3 pb-20">
      {/* Top Metrics Cards */}
      <div className="grid grid-cols-2 gap-2">
        <div className="bg-slate-900 text-white p-3.5 rounded-2xl shadow-xs">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            Cartera por Cobrar
          </span>
          <span className="text-xl font-black text-emerald-400 block mt-0.5">
            {formatCurrency(totalGlobalDebt)}
          </span>
          <span className="text-[10px] text-slate-400 mt-1 block">
            {clientes.length} clientes en ruta
          </span>
        </div>

        <div className="bg-white border border-slate-200 p-3.5 rounded-2xl shadow-2xs">
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
            Alertas de Mora
          </span>
          <div className="flex items-center gap-1.5 mt-0.5">
            <span className={`text-xl font-black ${totalOverdueClients > 0 ? 'text-rose-600' : 'text-slate-900'}`}>
              {totalOverdueClients}
            </span>
            <span className="text-xs text-slate-600 font-medium">con atraso</span>
          </div>
          <span className="text-[10px] text-rose-600 font-medium mt-1 block">
            {totalOverdueClients > 0 ? 'Requiere gestión hoy' : 'Sin clientes en mora'}
          </span>
        </div>
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
        <input
          id="search-client-input"
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Buscar por nombre, DNI o N° crédito..."
          className="w-full pl-9 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-hidden focus:border-emerald-500 shadow-2xs"
        />
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-1.5 text-xs overflow-x-auto pb-1">
        <button
          onClick={() => setFilterMode('ALL')}
          className={`px-3 py-1 rounded-lg font-bold transition-colors whitespace-nowrap ${
            filterMode === 'ALL'
              ? 'bg-slate-800 text-white'
              : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
          }`}
        >
          Todos ({clientStats.length})
        </button>
        <button
          onClick={() => setFilterMode('OVERDUE')}
          className={`px-3 py-1 rounded-lg font-bold transition-colors whitespace-nowrap flex items-center gap-1 ${
            filterMode === 'OVERDUE'
              ? 'bg-rose-600 text-white'
              : 'bg-white border border-slate-200 text-rose-700 hover:bg-rose-50'
          }`}
        >
          <AlertTriangle className="w-3.5 h-3.5" />
          Con Vencidas ({totalOverdueClients})
        </button>
        <button
          onClick={() => setFilterMode('ACTIVE')}
          className={`px-3 py-1 rounded-lg font-bold transition-colors whitespace-nowrap ${
            filterMode === 'ACTIVE'
              ? 'bg-emerald-600 text-white'
              : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
          }`}
        >
          Préstamos Activos
        </button>
      </div>

      {/* Clients Cards List */}
      <div className="space-y-2.5">
        {filteredList.length === 0 ? (
          <div className="p-8 text-center bg-white rounded-2xl border border-slate-200 text-slate-500">
            <User className="w-10 h-10 mx-auto text-slate-300 mb-2" />
            <p className="font-semibold text-slate-700">No se encontraron clientes</p>
            <p className="text-xs text-slate-400 mt-0.5">Prueba con otro término de búsqueda.</p>
          </div>
        ) : (
          filteredList.map(({ cliente, activeLoan, totalCuotas, paidCuotasCount, overdueCuotasCount, pendingDebt, hasOverdue }) => {
            return (
              <div
                key={cliente.codigo}
                onClick={() => onSelectCliente(cliente)}
                className={`bg-white rounded-2xl border transition-all shadow-2xs hover:shadow-xs cursor-pointer p-3.5 space-y-2.5 ${
                  hasOverdue ? 'border-rose-300 bg-rose-50/15' : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                {/* Top Row: Name, DNI, Status badge */}
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-extrabold text-sm text-slate-900">
                        {cliente.nombres} {cliente.apellidos}
                      </h4>
                      {hasOverdue && (
                        <span className="px-1.5 py-0.5 bg-rose-100 text-rose-700 font-bold text-[10px] rounded-md">
                          Mora ({overdueCuotasCount})
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-500 font-mono mt-0.5">
                      DNI: {cliente.dni} • Cod: {cliente.codigo}
                    </p>
                  </div>

                  <div className="text-right">
                    <span className="text-sm font-black text-slate-900 block">
                      {formatCurrency(pendingDebt)}
                    </span>
                    <span className="text-[10px] text-slate-500 font-medium">
                      Saldo pendiente
                    </span>
                  </div>
                </div>

                {/* Loan status summary */}
                {activeLoan ? (
                  <div className="p-2 bg-slate-50 rounded-xl flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-slate-800">
                        {activeLoan.id}
                      </span>
                      <span className="text-slate-400">•</span>
                      <span className="text-slate-600 font-medium">
                        {activeLoan.tipo_credito}
                      </span>
                    </div>

                    <div className="text-right">
                      <span className="font-bold text-emerald-700">
                        {paidCuotasCount}/{totalCuotas} cuotas
                      </span>
                    </div>
                  </div>
                ) : (
                  <p className="text-xs text-slate-400 italic">Sin préstamo activo</p>
                )}

                {/* Card Quick Actions */}
                <div className="flex items-center justify-between pt-1 border-t border-slate-100">
                  <div className="flex items-center gap-2">
                    {cliente.telefono && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          const clean = cleanPhoneNumber(cliente.telefono);
                          if (clean) window.open(`https://api.whatsapp.com/send?phone=${clean}`, '_blank');
                        }}
                        className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 hover:text-emerald-800 p-1 rounded-md hover:bg-emerald-50"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        <span>WhatsApp</span>
                      </button>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    {activeLoan && activeLoan.estado === 'ACTIVO' && pendingDebt > 0 && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onQuickPay(cliente, activeLoan);
                        }}
                        className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-2xs transition-colors flex items-center gap-1 active:scale-95"
                      >
                        <CreditCard className="w-3.5 h-3.5" />
                        Cobrar
                      </button>
                    )}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectCliente(cliente);
                      }}
                      className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs transition-colors flex items-center gap-0.5"
                    >
                      Detalle
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
