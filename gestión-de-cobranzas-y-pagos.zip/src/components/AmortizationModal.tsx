import React, { useState, useMemo } from 'react';
import { X, TrendingDown, ArrowRight, Check, AlertCircle } from 'lucide-react';
import { Cliente, Prestamo, Cuota, ReciboGenerado } from '../types';
import { formatCurrency, formatDate, getNowDateTimeString, getTodayDateString } from '../utils/storage';

interface AmortizationModalProps {
  cliente: Cliente;
  prestamo: Prestamo;
  cuotas: Cuota[];
  onClose: () => void;
  onSuccess: (recibo: ReciboGenerado, updatedCuotas: Cuota[], updatedCliente: Cliente, updatedPrestamo: Prestamo) => void;
}

export const AmortizationModal: React.FC<AmortizationModalProps> = ({
  cliente,
  prestamo,
  cuotas,
  onClose,
  onSuccess,
}) => {
  // Pending cuotas sorted by numero
  const pendingCuotas = useMemo(() => {
    return cuotas
      .filter((c) => c.prestamo_id === prestamo.id && c.estado !== 'PAGADO')
      .sort((a, b) => a.numero - b.numero);
  }, [cuotas, prestamo.id]);

  // Current outstanding debt across remaining cuotas
  const currentTotalDebt = useMemo(() => {
    return pendingCuotas.reduce((acc, c) => acc + (c.monto - c.monto_pagado), 0);
  }, [pendingCuotas]);

  // Suggested amounts (e.g. 1 cuota, 2 cuotas, half, or custom)
  const singleCuotaAmount = pendingCuotas[0]?.monto || 50;

  const [amountInput, setAmountInput] = useState<string>(singleCuotaAmount.toString());
  const [strategy, setStrategy] = useState<'FROM_END' | 'FROM_START'>('FROM_END');

  const amount = parseFloat(amountInput) || 0;
  const validAmount = amount > 0 && amount <= currentTotalDebt;

  // Simulation of which cuotas get affected
  const simulation = useMemo(() => {
    if (!validAmount) {
      return {
        remainingDebt: currentTotalDebt,
        affectedCuotasCount: 0,
        fullyPaidCount: 0,
        newRemainingCuotas: pendingCuotas.length,
        workingCuotas: [] as Cuota[],
      };
    }

    let remainingToDistribute = amount;
    const workingCuotas = pendingCuotas.map((c) => ({ ...c }));

    if (strategy === 'FROM_END') {
      // Apply backwards from the last installment to shorten loan duration
      for (let i = workingCuotas.length - 1; i >= 0 && remainingToDistribute > 0; i--) {
        const c = workingCuotas[i];
        const unpaidPart = c.monto - c.monto_pagado;
        if (remainingToDistribute >= unpaidPart) {
          remainingToDistribute -= unpaidPart;
          c.monto_pagado = c.monto;
          c.estado = 'PAGADO';
        } else {
          c.monto_pagado += remainingToDistribute;
          remainingToDistribute = 0;
        }
      }
    } else {
      // Apply forward from the next installment
      for (let i = 0; i < workingCuotas.length && remainingToDistribute > 0; i++) {
        const c = workingCuotas[i];
        const unpaidPart = c.monto - c.monto_pagado;
        if (remainingToDistribute >= unpaidPart) {
          remainingToDistribute -= unpaidPart;
          c.monto_pagado = c.monto;
          c.estado = 'PAGADO';
        } else {
          c.monto_pagado += remainingToDistribute;
          remainingToDistribute = 0;
        }
      }
    }

    const newUnpaid = workingCuotas.filter((c) => c.estado !== 'PAGADO');
    const newDebt = newUnpaid.reduce((acc, c) => acc + (c.monto - c.monto_pagado), 0);

    return {
      remainingDebt: Math.max(0, newDebt),
      newRemainingCuotas: newUnpaid.length,
      workingCuotas,
    };
  }, [validAmount, amount, currentTotalDebt, pendingCuotas, strategy]);

  const handleConfirm = () => {
    if (!validAmount || !simulation.workingCuotas) return;

    const today = getTodayDateString();
    const nowDateTime = getNowDateTimeString();
    const receiptId = `REC-AMORT-${Date.now().toString().slice(-6)}`;

    // Update the cuotas in the full list
    const updatedMap = new Map<number, Cuota>(simulation.workingCuotas.map((c) => [c.id, c]));
    const updatedCuotas = cuotas.map((c) => {
      const simulated = updatedMap.get(c.id);
      if (simulated) {
        return {
          ...simulated,
          fecha_pago_real: simulated.estado === 'PAGADO' ? today : c.fecha_pago_real,
        };
      }
      return c;
    });

    const isFinished = simulation.newRemainingCuotas === 0;
    const updatedPrestamo: Prestamo = {
      ...prestamo,
      estado: isFinished ? 'TERMINADO' : prestamo.estado,
    };

    const nextUpcoming = simulation.workingCuotas.find((c) => c.estado !== 'PAGADO');

    const recibo: ReciboGenerado = {
      id: receiptId,
      fecha_hora: nowDateTime,
      cliente,
      prestamo: updatedPrestamo,
      tipo_operacion: 'AMORTIZACION',
      cuotas_afectadas: [],
      total_cuotas: amount,
      total_mora: 0,
      saldo_favor_usado: 0,
      total_cobrado: amount,
      saldo_restante_prestamo: simulation.remainingDebt,
      cuotas_restantes: simulation.newRemainingCuotas,
      proximo_vencimiento: nextUpcoming ? formatDate(nextUpcoming.fecha_vencimiento) : null,
      observaciones: `Amortización extraordinaria (${
        strategy === 'FROM_END' ? 'Reducción de cuotas finales' : 'Abono a cuotas próximas'
      })`,
    };

    onSuccess(recibo, updatedCuotas, cliente, updatedPrestamo);
  };

  return (
    <div
      id="amortization-modal"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-950/80 backdrop-blur-xs overflow-y-auto"
    >
      <div className="relative w-full max-w-lg bg-white rounded-t-2xl sm:rounded-2xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3.5 bg-slate-900 text-white shrink-0">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-indigo-500/20 text-indigo-400">
              <TrendingDown className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[11px] font-semibold text-indigo-400 uppercase tracking-wider">
                Amortización Extraordinaria
              </span>
              <h3 className="font-bold text-base leading-tight">
                {cliente.nombres} {cliente.apellidos}
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-4 overflow-y-auto grow space-y-4">
          {/* Current Debt Card */}
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex justify-between items-center text-xs">
            <div>
              <span className="text-slate-500 block">Deuda total pendiente:</span>
              <span className="text-lg font-black text-slate-900">
                {formatCurrency(currentTotalDebt)}
              </span>
            </div>
            <div className="text-right">
              <span className="text-slate-500 block">Cuotas pendientes:</span>
              <span className="text-sm font-bold text-indigo-700">
                {pendingCuotas.length} cuotas
              </span>
            </div>
          </div>

          {/* Amount input */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Monto a Amortizar / Abonar
            </label>
            <div className="relative">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-bold text-slate-400 text-base">
                $
              </span>
              <input
                id="amortization-amount-input"
                type="number"
                step="1"
                min="1"
                max={currentTotalDebt}
                value={amountInput}
                onChange={(e) => setAmountInput(e.target.value)}
                className="w-full pl-8 pr-4 py-3 bg-white border-2 border-indigo-200 rounded-xl font-bold text-lg text-slate-900 focus:outline-hidden focus:border-indigo-600"
                placeholder="0.00"
              />
            </div>
            <div className="flex gap-2 mt-2">
              <button
                type="button"
                onClick={() => setAmountInput(singleCuotaAmount.toString())}
                className="px-2.5 py-1 text-xs bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-medium"
              >
                1 Cuota ({formatCurrency(singleCuotaAmount)})
              </button>
              {pendingCuotas.length >= 2 && (
                <button
                  type="button"
                  onClick={() => setAmountInput((singleCuotaAmount * 2).toString())}
                  className="px-2.5 py-1 text-xs bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-medium"
                >
                  2 Cuotas ({formatCurrency(singleCuotaAmount * 2)})
                </button>
              )}
              <button
                type="button"
                onClick={() => setAmountInput((Math.round(currentTotalDebt / 2)).toString())}
                className="px-2.5 py-1 text-xs bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-medium"
              >
                50% Deuda
              </button>
            </div>
          </div>

          {/* Amortization Strategy */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Método de Aplicación del Abono
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div
                onClick={() => setStrategy('FROM_END')}
                className={`p-3 rounded-xl border cursor-pointer transition-all ${
                  strategy === 'FROM_END'
                    ? 'border-indigo-600 bg-indigo-50/70 text-indigo-950 font-medium'
                    : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                }`}
              >
                <div className="font-bold flex items-center justify-between">
                  <span>Reducir Cuotas Finales</span>
                  {strategy === 'FROM_END' && <Check className="w-4 h-4 text-indigo-600" />}
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  Liquida las últimas cuotas del cronograma, reduciendo el plazo total.
                </p>
              </div>

              <div
                onClick={() => setStrategy('FROM_START')}
                className={`p-3 rounded-xl border cursor-pointer transition-all ${
                  strategy === 'FROM_START'
                    ? 'border-indigo-600 bg-indigo-50/70 text-indigo-950 font-medium'
                    : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                }`}
              >
                <div className="font-bold flex items-center justify-between">
                  <span>Abonar a Próximas Cuotas</span>
                  {strategy === 'FROM_START' && <Check className="w-4 h-4 text-indigo-600" />}
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  Adelanta el pago de las cuotas inmediatamente siguientes.
                </p>
              </div>
            </div>
          </div>

          {/* Simulation Preview Card */}
          {validAmount && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs space-y-2">
              <span className="font-bold text-emerald-900 block flex items-center gap-1.5">
                <TrendingDown className="w-4 h-4 text-emerald-700" />
                Impacto de la Amortización:
              </span>
              <div className="grid grid-cols-2 gap-2 pt-1 border-t border-emerald-200/60">
                <div>
                  <span className="text-slate-500 text-[11px]">Nuevo Saldo Deudor:</span>
                  <div className="flex items-center gap-1 font-bold text-slate-900">
                    <span className="line-through text-slate-400 text-xs">
                      {formatCurrency(currentTotalDebt)}
                    </span>
                    <ArrowRight className="w-3 h-3 text-emerald-600" />
                    <span className="text-emerald-700 font-extrabold text-sm">
                      {formatCurrency(simulation.remainingDebt)}
                    </span>
                  </div>
                </div>

                <div>
                  <span className="text-slate-500 text-[11px]">Cuotas Restantes:</span>
                  <div className="flex items-center gap-1 font-bold text-slate-900">
                    <span className="line-through text-slate-400 text-xs">
                      {pendingCuotas.length}
                    </span>
                    <ArrowRight className="w-3 h-3 text-emerald-600" />
                    <span className="text-emerald-700 font-extrabold text-sm">
                      {simulation.newRemainingCuotas} cuotas
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {amount > currentTotalDebt && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>
                El monto no puede ser mayor que la deuda total ({formatCurrency(currentTotalDebt)}).
                Si desea liquidar todo, use la opción "Cancelar Préstamo".
              </span>
            </div>
          )}
        </div>

        {/* Action Button */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 shrink-0">
          <button
            id="confirm-amortization-btn"
            disabled={!validAmount}
            onClick={handleConfirm}
            className="w-full py-3 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 disabled:cursor-not-allowed text-white font-bold text-sm shadow-md transition-all active:scale-[0.98] flex items-center justify-center gap-2"
          >
            <Check className="w-5 h-5 stroke-[2.5]" />
            Registrar Amortización de {formatCurrency(validAmount ? amount : 0)}
          </button>
        </div>
      </div>
    </div>
  );
};
